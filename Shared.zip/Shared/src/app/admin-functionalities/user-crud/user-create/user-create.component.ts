import { Component } from '@angular/core';

@Component({
  selector: 'app-user-create',
  imports: [],
  templateUrl: './user-create.component.html',
  styleUrl: './user-create.component.css'
})
export class UserCreateComponent {

}
