export interface AuthResponse {
  accessToken: string;
  roleId: number;
  userId: number;
  }
  