export const environment = {
    production: false,
    apiUrl: 'https://localhost:7246/api' // Change this to your actual backend API URL
  };  